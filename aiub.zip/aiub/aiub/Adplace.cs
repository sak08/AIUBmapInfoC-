﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace aiub
{
    public partial class Adplace : Form
    {
        public Adplace()
        {
            InitializeComponent();
           
            addplace1.BringToFront();
            panel2.BackColor = Color.DeepSkyBlue;
            panel3.BackColor = Color.DeepSkyBlue;
            button3.BackColor = Color.Crimson;
            
            button8.BackColor = Color.DeepSkyBlue;
            button1.BackColor = Color.FromArgb(64, 64, 64);
            button2.BackColor = Color.FromArgb(64, 64, 64);
            
        }

        private void update_Load(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {

           
            upplace1.BringToFront();
            panel2.BackColor = Color.DeepSkyBlue;
            panel3.BackColor = Color.DeepSkyBlue;
            button1.BackColor = Color.Crimson;
           
            button1.BackColor = Color.DeepSkyBlue;
            button2.BackColor = Color.FromArgb(64, 64, 64);
            button8.BackColor = Color.FromArgb(64, 64, 64);

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            
            delplace1.BringToFront();
            panel2.BackColor = Color.Crimson;
            panel3.BackColor = Color.Crimson;
            button3.BackColor = Color.DeepSkyBlue;
            
            button2.BackColor = Color.Crimson;
            button1.BackColor = Color.FromArgb(64, 64, 64);
            button8.BackColor = Color.FromArgb(64, 64, 64);

        }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {

        }

        private void upplace1_Load(object sender, EventArgs e)
        {
            
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            admin a = new admin();
            a.Show();
            this.Hide();
        }

        private void button8_Click(object sender, EventArgs e)
        {
           
            addplace1.BringToFront();
            panel2.BackColor = Color.DeepSkyBlue;
            panel3.BackColor = Color.DeepSkyBlue;
            button1.BackColor = Color.Crimson;
            
            button8.BackColor = Color.DeepSkyBlue;
            button1.BackColor = Color.FromArgb(64,64,64);
            button2.BackColor = Color.FromArgb(64, 64, 64);

        }
    }
}
