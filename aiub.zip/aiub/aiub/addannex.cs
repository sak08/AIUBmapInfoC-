﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace aiub
{
    public partial class addannex : Form
    {
        public addannex()
        {
            InitializeComponent();
            panel2.BackColor = Color.DeepSkyBlue;
            panel3.BackColor = Color.DeepSkyBlue;
            button4.BackColor = Color.Red;
            button8.BackColor = Color.DeepSkyBlue;
            button9.BackColor = Color.FromArgb(64, 64, 64);
            button2.BackColor = Color.FromArgb(64, 64, 64);
            addanx1.BringToFront();
            
        }

        private void button8_Click(object sender, EventArgs e)
        {
            panel2.BackColor = Color.DeepSkyBlue;
            panel3.BackColor = Color.DeepSkyBlue;
            addanx1.BringToFront();
            button4.BackColor = Color.Red;
            button8.BackColor = Color.DeepSkyBlue;
            button9.BackColor = Color.FromArgb(64, 64, 64);
            button2.BackColor = Color.FromArgb(64, 64, 64);
        }

        private void button9_Click(object sender, EventArgs e)
        {
            button9.BackColor = Color.Crimson;
            button8.BackColor = Color.FromArgb(64, 64, 64);
            button2.BackColor = Color.FromArgb(64, 64, 64);
            delanx1.BringToFront();
            panel2.BackColor = Color.Crimson;
            panel3.BackColor = Color.Crimson;
            button4.BackColor = Color.DeepSkyBlue;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            admin a = new admin();
            a.Show();
            this.Hide();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            upanx1.BringToFront();
            button4.BackColor = Color.Red;
            button2.BackColor = Color.DeepSkyBlue;
            button9.BackColor = Color.FromArgb(64, 64, 64);
            button8.BackColor = Color.FromArgb(64, 64, 64);
            panel2.BackColor = Color.DeepSkyBlue;
            panel3.BackColor = Color.DeepSkyBlue;
        }
    }
}
