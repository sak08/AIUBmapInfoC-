﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

using System.IO;

using BLL;



namespace aiub
{
    public partial class upplace : UserControl
    {
        public upplace()
        {
            InitializeComponent();
        }
        Place s = new Place();

        private void GridViewShow()
        {

            dataGridView1.DataSource = s.GetAllPlaces();

        }

        private void button5_Click(object sender, EventArgs e)
        {
            
        }

        private void dataGridView1_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = Image.FromFile(dataGridView1.CurrentRow.Cells[3].Value.ToString());

            id.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            pname.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            floorno.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();  
        }
        
        private void button1_Click(object sender, EventArgs e)
        {
            string fname = id.Text + "up.jpg";
            string folder = "G:\\p";
            string pathstring = Path.Combine(folder, fname);

            Image a = pictureBox1.Image;
            a.Save(pathstring);

            s.UpPlace(int.Parse(id.Text), pname.Text, floorno.Text, pathstring);
            MessageBox.Show("Place Updated");
            GridViewShow();
        }


     
        private void upplace_Load(object sender, EventArgs e)
        {
            GridViewShow();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

            OpenFileDialog open = new OpenFileDialog();
            PictureBox p = sender as PictureBox;
            if (p != null)
            {
                open.Filter = "(*.jpg;*.png;)|*.jpg;*.png;";
                if (open.ShowDialog() == DialogResult.OK)
                {
                    p.Image = Image.FromFile(open.FileName);
                }
            }
        }
    }
}
