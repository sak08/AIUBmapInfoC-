﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using BLL;

namespace aiub
{
    public partial class delrom : UserControl
    {
        public delrom()
        {
            InitializeComponent();
        }
        
        Room r = new Room();


        private void GridViewShow()
        {

            dataGridView1.DataSource = r.GetAllRooms();

        }
     
        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult res = MessageBox.Show("Are you sure?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (res.Equals(DialogResult.Yes))
            {
                r.DelRoom(int.Parse(textBox2.Text));
                MessageBox.Show("Room Deleted");
                GridViewShow();
            }
            else
            {
                MessageBox.Show("Not Deleted");
                GridViewShow();
            }
        }
   

        private void delrom_Load(object sender, EventArgs e)
        {
            GridViewShow();
        }
    }
}
