﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.IO;


namespace aiub
{
    public class Data
    {

            //SqlConnection con;
            //public Data()
            //{
               // con = new SqlConnection(@"Data Source=DESKTOP-N9GJFPQ\SQLEXPRESS;Initial Catalog=aiub;Integrated Security=True");
               // con.Open();
          //  }

            /*public DataTable GetAll()
            {
                SqlCommand str = new SqlCommand("Select * from annex1", con);
                SqlDataAdapter da = new SqlDataAdapter(str);
                DataTable dt = new DataTable();
                da.Fill(dt);
                con.Close();
                return dt;
            }

            public DataTable SearchById(int room)
            {

                if ((room.ToString()).Substring(0, 1) == "1")
                {
                    SqlCommand str = new SqlCommand("Select * from annex1 where [Room Numb]=" + room, con);

                    SqlDataAdapter da = new SqlDataAdapter(str);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    con.Close();
                    return dt;


                }
                else
                {
                    SqlCommand str = new SqlCommand("Select * from annex2 where [Room Numb]=" + room, con);
                    SqlDataAdapter da = new SqlDataAdapter(str);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    con.Close();
                    return dt;
                }
            }*/

           // public void addannex(string name,int id)
            //{
            //    
                

               // con.Open();
               // SqlCommand str = new SqlCommand("insert into Annex values('" + name + "')", con);

               // str.ExecuteNonQuery();
        //

           // }
       



        }
    }


