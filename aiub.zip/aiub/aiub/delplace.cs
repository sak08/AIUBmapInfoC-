﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using BLL;

namespace aiub
{
    public partial class delplace : UserControl
    {
        public delplace()
        {
            InitializeComponent();
        }
       Place r = new Place();


        private void GridViewShow()
        {

            dataGridView1.DataSource = r.GetAllPlaces();

        }
       
        
        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult res = MessageBox.Show("Are you sure?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (res.Equals(DialogResult.Yes))
            {
                r.DelPlace(int.Parse(textBox1.Text));
                MessageBox.Show("Room Deleted");
                GridViewShow();
            }
            else
            {
                MessageBox.Show("Not Deleted");
                GridViewShow();
            }
        }

        private void delplace_Load(object sender, EventArgs e)
        {
            GridViewShow();
        }
    }
}
