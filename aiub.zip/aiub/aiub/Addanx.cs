﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using BLL;

namespace aiub
{
    public partial class addanx : UserControl
    {
        public addanx()
        {
            InitializeComponent();
        }
        Annex r = new Annex();
      



        private void GridViewShow()
        {

            dataGridView1.DataSource = r.GetAllAnnexs();

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            PictureBox p = sender as PictureBox;
            if (p != null)
            {
                open.Filter = "(*.jpg;*.png;)|*.jpg;*.png;";
                if (open.ShowDialog() == DialogResult.OK)
                {
                    p.Image = Image.FromFile(open.FileName);
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (pictureBox1 != null)
            {
                string fname = anxnum.Text + ".jpg";
                string folder = "G:\\p";
                string pathstring = Path.Combine(folder, fname);

                Image a = pictureBox1.Image;
                a.Save(pathstring);

                r.InsertAnnex(int.Parse(anxnum.Text),name.Text, pathstring);
                MessageBox.Show("Annex Added");
            }
            else { MessageBox.Show("Insert waypoint"); }

            GridViewShow();
        }

        private void dataGridView1_Click(object sender, EventArgs e)
        {
           

           anxnum.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            name.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            pictureBox1.Image = Image.FromFile(dataGridView1.CurrentRow.Cells[2].Value.ToString());
            
        }

        private void addanx_Load(object sender, EventArgs e)
        {
            GridViewShow();
        }

        private void dataGridView1_Click_1(object sender, EventArgs e)
        {
            anxnum.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            name.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            pictureBox1.Image = Image.FromFile(dataGridView1.CurrentRow.Cells[2].Value.ToString());
        }
    }
}
