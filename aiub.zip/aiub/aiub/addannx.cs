﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace aiub
{
    public partial class addannx : UserControl
    {
        public addannx()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-N9GJFPQ\SQLEXPRESS;Initial Catalog=aiub;Integrated Security=True;Pooling=False");


        string imgLocation = "";
        


        private void button6_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "png files(*.png)|*.png|jpg files(*.jpg)|*.jpg|ALL files(*.*)|*.*";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                imgLocation = dialog.FileName.ToString();
                pictureBox3.ImageLocation = imgLocation;
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            MemoryStream ms = new MemoryStream();
            pictureBox3.Image.Save(ms, pictureBox3.Image.RawFormat);
            byte[] img = ms.ToArray();

            SqlCommand c = new SqlCommand("Insert into Annex(AnnexNumber,AnnexName,waypoint)Values('" + id.Text + "','" + name.Text + "',@waypoint)", con);
            //c.Parameters.Add("@room", SqlDbType.Int).Value = id.Text;
           // c.Parameters.Add("@anx", SqlDbType.Int).Value = name.Text;
           
           // c.Parameters.Add("@waypoint", SqlDbType.Image).Value = img;
            exquery(c, "Annex Added");
        }

        public void dgv()
        {
            SqlCommand c = new SqlCommand("SELECT * FROM Annex", con);
            SqlDataAdapter a = new SqlDataAdapter(c);
            DataTable t = new DataTable();
            a.Fill(t);
            dataGridView1.DataSource = t;
            dataGridView1.AllowUserToAddRows = false;


        }

        public void exquery(SqlCommand m, string n)
        {
            con.Open();
            if (m.ExecuteNonQuery() == 1)
            { MessageBox.Show(n); }
            else
            { MessageBox.Show("Query Not Executed"); }
            dgv();
        }

        private void addannx_Load(object sender, EventArgs e)
        {
            dgv();
        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }



    }
}
