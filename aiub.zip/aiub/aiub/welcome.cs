﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace aiub
{
    public partial class welcome : Form
    {
        public welcome()
        {
            InitializeComponent();
            button1.BackColor = Color.DeepSkyBlue;
            button2.BackColor = Color.FromArgb(64, 64, 64);
            
            info1.BringToFront();
        }

        private void welcome_Load(object sender, EventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            button1.BackColor = Color.DeepSkyBlue;
            button2.BackColor = Color.FromArgb(64, 64, 64);

            info1.BringToFront();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            button2.BackColor = Color.DeepSkyBlue;
            button1.BackColor = Color.FromArgb(64, 64, 64);
            pic1.BringToFront();
        }

        private void logout_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 f = new Form1();
            f.Show();
        }
    }
}
