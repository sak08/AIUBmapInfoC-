﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BLL;
using System.IO;

namespace aiub
{
    public partial class upanx : UserControl
    {
        public upanx()
        {
            InitializeComponent();
        }
       Annex s = new Annex();

        private void GridViewShow()
        {

            dataGridView1.DataSource = s.GetAllAnnexs();

        }
        private void upanx_Load(object sender, EventArgs e)
        {
            GridViewShow();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string fname = id.Text + "up.jpg";
            string folder = "G:\\p";
            string pathstring = Path.Combine(folder, fname);

            Image a = pictureBox1.Image;
            a.Save(pathstring);

            s.UpAnnex(int.Parse(id.Text), aname.Text, pathstring);
            MessageBox.Show("Annex Updated");
            GridViewShow();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

            OpenFileDialog open = new OpenFileDialog();
            PictureBox p = sender as PictureBox;
            if (p != null)
            {
                open.Filter = "(*.jpg;*.png;)|*.jpg;*.png;";
                if (open.ShowDialog() == DialogResult.OK)
                {
                    p.Image = Image.FromFile(open.FileName);
                }
            }
        }

        private void dataGridView1_Click(object sender, EventArgs e)
        {
            id.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            aname.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            pictureBox1.Image = Image.FromFile(dataGridView1.CurrentRow.Cells[2].Value.ToString());
        }

        private void dataGridView1_Click_1(object sender, EventArgs e)
        {
            id.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            aname.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            pictureBox1.Image = Image.FromFile(dataGridView1.CurrentRow.Cells[2].Value.ToString());
        }
    }
}
