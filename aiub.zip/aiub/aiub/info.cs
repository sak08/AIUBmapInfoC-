﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BLL;

namespace aiub
{
    public partial class info : UserControl
    {
        public info()
        {
            InitializeComponent();
        }
        Room r = new Room();
        Annex a=new Annex();
        Place p=new Place();
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = r.SearchRoom(int.Parse(textBox1.Text));
            dataGridView1.Columns["Waypoint"].Visible = false;
        }
    }
}
