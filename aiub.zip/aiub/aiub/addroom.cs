﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace aiub
{
    public partial class addroom : Form
    {
          
            
        public addroom()
        {
            InitializeComponent();
            
            addrom1.BringToFront();
            panel2.BackColor = Color.DeepSkyBlue;
            panel3.BackColor = Color.DeepSkyBlue;
            button1.BackColor = Color.Crimson;
            button8.BackColor = Color.DeepSkyBlue;
            button1.BackColor = Color.FromArgb(64, 64, 64);
            button2.BackColor = Color.FromArgb(64, 64, 64);
           
            
        }

      
        private void addroom_Load(object sender, EventArgs e)
        {

        }

        private void button8_Click(object sender, EventArgs e)
        {
            button8.BackColor = Color.DeepSkyBlue;
            button2.BackColor = Color.FromArgb(64, 64, 64);
            button9.BackColor = Color.FromArgb(64, 64, 64);
            addrom1.BringToFront();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            uproom1.BringToFront();
            panel2.BackColor = Color.DeepSkyBlue;
            panel3.BackColor = Color.DeepSkyBlue;
            button1.BackColor = Color.Crimson;
            button2.BackColor = Color.DeepSkyBlue;
            button9.BackColor = Color.FromArgb(64, 64, 64);
            button8.BackColor = Color.FromArgb(64, 64, 64);
            
        }

        private void button9_Click(object sender, EventArgs e)
        {
            
            delrom1.BringToFront();
            panel2.BackColor = Color.Crimson;
            panel3.BackColor = Color.Crimson;
            button1.BackColor = Color.DeepSkyBlue;
            button9.BackColor = Color.Crimson;
            button2.BackColor = Color.FromArgb(64, 64, 64);
            button8.BackColor = Color.FromArgb(64, 64, 64);
            
        }

        private void addannx1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            admin a = new admin();
            a.Show();
            this.Hide();
        }
    }
}
