﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace aiub
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-N9GJFPQ\SQLEXPRESS;Initial Catalog=aiub;Integrated Security=True;Pooling=False");
            SqlDataAdapter s = new SqlDataAdapter("Select Count(*) From Admin where username='" + textBox2.Text + "' and password='" + textBox1.Text + "'", con);
            DataTable dt = new DataTable();
            s.Fill(dt);
            if (dt.Rows[0][0].ToString()=="1")
            {
                admin w = new admin();
                w.Show();
                this.Hide();

            }
            else if (textBox2.Text == "student")
            {
                welcome w = new welcome();
                w.Show();
                this.Hide();

            }
            else
            { MessageBox.Show("Insert correct username or password"); }
            
            
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            textBox3.Select();
            if (Control.IsKeyLocked(Keys.CapsLock))
            { label2.Text = "Caps Lock is on"; }
            else
            { label2.Text = "Caps Lock is off"; }
        }
        
        private void textBox2_Click(object sender, EventArgs e)
        {
            textBox2.Text = "";
            
        }

        private void textBox1_Click(object sender, EventArgs e)
        {
            textBox1.UseSystemPasswordChar = false;
            textBox1.Text = "";
           
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (Control.IsKeyLocked(Keys.CapsLock))
            { label2.Text = "Caps Lock is on"; }
            else
            { label2.Text = "Caps Lock is off"; }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
