﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using BLL;

namespace aiub
{
    public partial class uproom : UserControl
    {
        public uproom()
        {
            InitializeComponent();
        }

        Room s = new Room();

        private void GridViewShow()
        {

            dataGridView1.DataSource = s.GetAllRooms();

        }
        
        private void button5_Click(object sender, EventArgs e)
        {
           
        }


        private void button1_Click(object sender, EventArgs e)
        {

            string fname = roomno.Text + "up.jpg";
            string folder = "G:\\p";
            string pathstring = Path.Combine(folder, fname);

            Image a = pictureBox1.Image;
            a.Save(pathstring);

            s.UpRoom(int.Parse(roomno.Text), int.Parse(anxno.Text), floorno.Text, pathstring);
            MessageBox.Show("Room Updated");
            GridViewShow();

        }


        private void uproom_Load(object sender, EventArgs e)
        {
            GridViewShow();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void uproom_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = Image.FromFile(dataGridView1.CurrentRow.Cells[3].Value.ToString());

            roomno.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            anxno.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            floorno.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString(); ;

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

            OpenFileDialog open = new OpenFileDialog();
            PictureBox p = sender as PictureBox;
            if (p != null)
            {
                open.Filter = "(*.jpg;*.png;)|*.jpg;*.png;";
                if (open.ShowDialog() == DialogResult.OK)
                {
                    p.Image = Image.FromFile(open.FileName);
                }
            }
        }


    }
}
