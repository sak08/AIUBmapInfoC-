﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using BLL;

namespace aiub
{
    public partial class delanx : UserControl
    {
        public delanx()
        {
            InitializeComponent();
        }
        Annex r = new Annex();




        private void GridViewShow()
        {

            dataGridView1.DataSource = r.GetAllAnnexs();

        }

      

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult res = MessageBox.Show("Are you sure?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (res.Equals(DialogResult.Yes))
            {
                r.DelAnnex(int.Parse(textBox2.Text));
                MessageBox.Show("Annex Deleted");
                GridViewShow();
            }
            else
            {
                MessageBox.Show("Not Deleted");
                GridViewShow();
            }
        }
       

        private void delanx_Load(object sender, EventArgs e)
        {
            GridViewShow();
        }
    }
}
