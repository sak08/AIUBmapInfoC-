﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;


namespace aiub
{
    public class Annex
    {


        public string Annex_Numb { get; set; }
        public int Room_Numb { get; set; }
        public string Floor { get; set; }

        Data da = new Data();

        /*public List<Annex> GetAllannexs()
        {
            var annexs = new List<Annex>();
            for (int i = 0; i < da.GetAll().Rows.Count; i++)
            {
                var annex = new Annex();
                annex.Annex_Numb = da.GetAll().Rows[i]["Annex Numb"].ToString();
                annex.Room_Numb = int.Parse(da.GetAll().Rows[i]["Room Numb"].ToString());
                annex.Floor = da.GetAll().Rows[i]["Floor"].ToString();

                annexs.Add(annex);
            }

            return annexs;
        }

        public List<Annex> SearchById(int room)
        {
            var annexs = new List<Annex>();
            var annex = new Annex();
            annex.Annex_Numb = da.SearchById(room).Rows[0]["Annex Numb"].ToString();
            annex.Room_Numb = int.Parse(da.SearchById(room).Rows[0]["Room Numb"].ToString());
                annex.Floor = da.SearchById(room).Rows[0]["Floor"].ToString();
                annexs.Add(annex);
            

            return annexs;
    
    
    
    }*/
    }
}
