﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using System.IO;
namespace BLL
{
    public class Annex
    {

        public int AnnexNo { get; set; }
        public string AnnexName { get; set; }
        
        public string Waypoint { get; set; }
       


        DataAccess da = new DataAccess();

        public List<Annex> GetAllAnnexs()
        {
            var annexs = new List<Annex>();
            for (int i = 0; i < da.GetAllAnnex().Rows.Count; i++)
            {
                var annex = new Annex();
               annex.AnnexNo = int.Parse(da.GetAllAnnex().Rows[i]["AnnexNo"].ToString());
                annex.AnnexName = da.GetAllAnnex().Rows[i]["AnnexName"].ToString();
                annex.Waypoint = da.GetAllAnnex().Rows[i]["Waypoint"].ToString();
                annexs.Add(annex);
            }

            return annexs;
        }
        public void InsertAnnex(int AnnexNo, string AnnexName,string Waypoint)
        {
            da.addannex(AnnexNo,AnnexName, Waypoint);
        }
        public void DelAnnex(int AnnexNo)
        {
            da.delannex(AnnexNo);
        }
        public void UpAnnex(int AnnexNo, string AnnexName, string Waypoint)
        {
            da.upannex(AnnexNo, AnnexName, Waypoint);
        }

        public List<Annex> SearchAnnex(int id)
        {
            var annexs = new List<Annex>();
            var annex = new Annex();
            annex.AnnexNo = int.Parse(da.SearchAnx(id).Rows[0]["Id"].ToString());
            annex.AnnexName = da.SearchAnx(id).Rows[0]["Name"].ToString();
            annexs.Add(annex);
            return annexs;
        }

    }
}
