﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using DAL;
using System.IO;

namespace BLL
{
    public class Room
    {
        public int RoomNumber { get; set; }
        public int AnnexNo { get; set; }
        public string FloorNo { get; set; }
        public string Waypoint { get; set; }
       

        DataAccess da = new DataAccess();

        public List<Room> GetAllRooms()
        {
            var rooms = new List<Room>();
            for (int i = 0; i < da.GetAllRoom().Rows.Count; i++)
            {
                var room = new Room();
               room.RoomNumber = int.Parse(da.GetAllRoom().Rows[i]["RoomNo"].ToString());
                room.AnnexNo = int.Parse(da.GetAllRoom().Rows[i]["AnnexNo"].ToString());
                room.FloorNo= da.GetAllRoom().Rows[i]["FLoorNo"].ToString();
                room.Waypoint = da.GetAllRoom().Rows[i]["Waypoint"].ToString();
                rooms.Add(room);
            }

            return rooms;
        }
        public void InsertRoom(int RoomNumber, int AnnexNo, string FloorNo, string Waypoint)
        {
            da.addroom(RoomNumber, AnnexNo, FloorNo, Waypoint);
        }
        public void DelRoom(int RoomNumber)
        {
            da.delroom(RoomNumber);
        }
        public void UpRoom(int RoomNumber, int AnnexNo, string FloorNo, string Waypoint)
        {
            da.uproom(RoomNumber, AnnexNo, FloorNo, Waypoint);
        }

        public List<Room> SearchRoom(int no)
        {
            var rooms = new List<Room>();
            var room= new Room();
            room.RoomNumber = int.Parse(da.Searchroom(no).Rows[0]["RoomNo"].ToString());
            room.AnnexNo = int.Parse(da.Searchroom(no).Rows[0]["AnnexNo"].ToString());
            room.FloorNo = da.Searchroom(no).Rows[0]["FloorNo"].ToString();
            rooms.Add(room);
            return rooms;
        }


    }
}
