﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using System.IO;

namespace BLL
{
    public class Place
    {
        public int PlaceId { get; set; }
        public string PlaceName { get; set; }
        public string FloorNo { get; set; }
        public string Waypoint { get; set; }
        MemoryStream ms = new MemoryStream();
       

        DataAccess da = new DataAccess();

        public List<Place> GetAllPlaces()
        {
            var places = new List<Place>();
            for (int i = 0; i < da.GetAllPlace().Rows.Count; i++)
            {
                MemoryStream ms = new MemoryStream();
                var place= new Place();
                place.PlaceId = int.Parse(da.GetAllPlace().Rows[i]["PID"].ToString());
                place.PlaceName= da.GetAllPlace().Rows[i]["PlaceName"].ToString();
                place.FloorNo = da.GetAllPlace().Rows[i]["FLoorNo"].ToString();
                place.Waypoint = da.GetAllPlace().Rows[i]["Waypoint"].ToString();
                places.Add(place);
            }

            return places;
        }
        public void InsertPlace(int PlaceId,string PlaceName,string FloorNo,string Waypoint)
        {
            da.addplace(PlaceId,PlaceName,FloorNo,Waypoint);
        }
        public void DelPlace(int PlaceId)
        {
            da.delplace(PlaceId);
        }

        public void UpPlace(int PlaceId, string PlaceName, string FloorNo, string Waypoint)
        {
            da.upplace(PlaceId, PlaceName, FloorNo, Waypoint);
        }

        public List<Place> SearchPlace(int id)
        {
            var places = new List<Place>();
            var place = new Place();
            place.PlaceId = int.Parse(da.Searchplace(id).Rows[0]["Id"].ToString());
            place.PlaceName = da.Searchplace(id).Rows[0]["Name"].ToString();
            places.Add(place);
            return places;
        }


    }
}
