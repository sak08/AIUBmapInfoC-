﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.IO;

namespace DAL
{   
   
    public class DataAccess
    {
        SqlConnection con;
        
         public DataAccess()
        {

            con = new SqlConnection(@"Data Source=DESKTOP-N9GJFPQ\SQLEXPRESS;Initial Catalog=aiub;Integrated Security=True;Pooling=False");
            con.Open();


        }
         public DataTable GetAllRoom()
         {
             SqlCommand str = new SqlCommand("Select * from Rooms", con);
             SqlDataAdapter da = new SqlDataAdapter(str);
             DataTable dt = new DataTable();
             da.Fill(dt);
             con.Close();
             return dt;
         }
         public DataTable GetAllAnnex()
         {
             SqlCommand str = new SqlCommand("Select * from anxs", con);
             SqlDataAdapter da = new SqlDataAdapter(str);
             DataTable dt = new DataTable();
             da.Fill(dt);
             con.Close();
             return dt;
         }
         public DataTable GetAllPlace()
         {
             SqlCommand str = new SqlCommand("Select * from plc", con);
             SqlDataAdapter da = new SqlDataAdapter(str);
             DataTable dt = new DataTable();
             da.Fill(dt);
             con.Close();
             return dt;
         }
        


        //annex
         public void addannex(int num,string name,string waypoint)
         {
             con.Open();
             SqlCommand str = new SqlCommand("Insert into anxs(AnnexNo,AnnexName,Waypoint)Values('" + num+ "','" + name + "','" + waypoint + "')", con);

             str.ExecuteNonQuery();
         }
         public void delannex(int num)
         {
             con.Open();
             SqlCommand str = new SqlCommand("Delete from anxs where AnnexNo=" + num, con);

             str.ExecuteNonQuery();
         }

         public void upannex(int num, string name, string waypoint)
         {
             con.Open();
             SqlCommand c = new SqlCommand("UPDATE anxs SET AnnexName=@aname,Waypoint=@waypoint WHERE AnnexNo=@anx", con);
             c.Parameters.Add("@anx", SqlDbType.Int).Value = num;
             c.Parameters.Add("@aname", SqlDbType.VarChar).Value = name;
             c.Parameters.Add("@waypoint", SqlDbType.VarChar).Value = waypoint;
             c.ExecuteNonQuery();   
         }





        //room
         public void addroom(int num, int name, string f, string waypoint)
         {
             con.Open();
             SqlCommand str = new SqlCommand("Insert into Rooms(RoomNo,AnnexNo,FloorNo,Waypoint)Values('" + num + "','" + name + "','" + f + "','" + waypoint + "')", con);

             str.ExecuteNonQuery();
         }
         public void delroom(int num)
         {
             con.Open();
             SqlCommand str = new SqlCommand("Delete from Rooms where RoomNo=" + num ,con);

             str.ExecuteNonQuery();
         }

         public void uproom(int RoomNumber, int AnnexNo, string FloorNo, string Waypoint)
         {
             con.Open();
             SqlCommand c = new SqlCommand("UPDATE Rooms SET AnnexNo=@anx,FloorNo=@flr,Waypoint=@waypoint WHERE RoomNo=@room", con);
             c.Parameters.Add("@room", SqlDbType.Int).Value = RoomNumber;
             c.Parameters.Add("@anx", SqlDbType.Int).Value = AnnexNo;
             c.Parameters.Add("@flr", SqlDbType.VarChar).Value = FloorNo;
             c.Parameters.Add("@waypoint", SqlDbType.VarChar).Value = Waypoint;
             c.ExecuteNonQuery();
         }





        //place
         public void addplace(int id, string name, string flr, string waypoint)
         {
             con.Open();
             SqlCommand str = new SqlCommand("Insert into plc(PID,PlaceName,FloorNo,Waypoint)Values('" + id + "','" + name + "','" + flr + "','" + waypoint + "')", con);

             str.ExecuteNonQuery();
         }
         public void delplace(int id)
         {
             con.Open();
             SqlCommand str = new SqlCommand("Delete from plc where PID=" + id, con);

             str.ExecuteNonQuery();
         }

         public void upplace(int PlaceId, string PlaceName, string FloorNo, string Waypoint)
         {

             con.Open();
             SqlCommand str = new SqlCommand("UPDATE plc SET PlaceName=@name,FloorNo=@flr,Waypoint=@waypoint WHERE PID=@pid", con);
             str.Parameters.Add("@pid", SqlDbType.Int).Value = PlaceId;
             str.Parameters.Add("@name", SqlDbType.VarChar).Value = PlaceName;
             str.Parameters.Add("@flr", SqlDbType.VarChar).Value = FloorNo;
             str.Parameters.Add("@waypoint", SqlDbType.VarChar).Value = Waypoint;
             str.ExecuteNonQuery();
         }

         public DataTable SearchAnx(int id)
         {
             SqlCommand str = new SqlCommand("Select * from anxs where AnnexNo=" + id, con);

             SqlDataAdapter da = new SqlDataAdapter(str);
             DataTable dt = new DataTable();
             da.Fill(dt);
             con.Close();
             return dt;
         }

         public DataTable Searchplace(int id)
         {
             SqlCommand str = new SqlCommand("Select * from plc where PID=" + id, con);

             SqlDataAdapter da = new SqlDataAdapter(str);
             DataTable dt = new DataTable();
             da.Fill(dt);
             con.Close();
             return dt;
         }
         public DataTable Searchroom(int id)
         {
             SqlCommand str = new SqlCommand("Select * from Rooms where RoomNo=" + id, con);
            
                 SqlDataAdapter da = new SqlDataAdapter(str);

                 DataTable dt = new DataTable();
                 da.Fill(dt);
                 con.Close();
                 return dt;
             }
            
         }
        


    }

